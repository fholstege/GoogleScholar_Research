
getwd()
setwd("/Users/FlorisHolstege/Documents/Freelance/GoogleScholar_Research/gscholar")

links = read.csv("files/master_links_Googlescholar.csv")


length(unique(links$https...scholar.google.com..citations.user.AKqYlxMAAAAJ.hl.en))
